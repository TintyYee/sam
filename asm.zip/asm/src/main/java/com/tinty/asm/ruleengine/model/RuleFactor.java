package com.tinty.asm.ruleengine.model;

import lombok.Data;

import java.util.List;

@Data
public class RuleFactor {
    private String name;
    private List<RuleFactorField> fields;
}
