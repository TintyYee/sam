package com.tinty.asm.ruleengine.model;

import lombok.Data;

@Data
public class RuleFactorField {
    private String name;
    private String type;
}
