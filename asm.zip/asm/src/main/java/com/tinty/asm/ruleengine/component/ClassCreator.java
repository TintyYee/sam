package com.tinty.asm.ruleengine.component;

import com.tinty.asm.demo.FileUtils;
import com.tinty.asm.ruleengine.model.RuleFactor;
import com.tinty.asm.ruleengine.model.RuleFactorField;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.MethodVisitor;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import static org.objectweb.asm.Opcodes.*;

/**
 * 字节码生成器
 *
 */
public class ClassCreator {
    byte[] bytes;

    /**
     * 生成class，byte格式
     *
     * @param ruleFactor 规则因子
     * @return ClassCreator
     */
    public ClassCreator createByte(RuleFactor ruleFactor){
        String classPath = "com/tinty/asm/ruleengine/model/" + ruleFactor.getName();
        ClassWriter classWriter = new ClassWriter(ClassWriter.COMPUTE_FRAMES);
        // 类信息
        classWriter.visit(V1_8, ACC_PUBLIC | ACC_SUPER, classPath, null, "java/lang/Object", null);
        // init构造方法信息
        {
            MethodVisitor methodVisitor = classWriter.visitMethod(ACC_PUBLIC, "<init>", "()V", null, null);
            methodVisitor.visitCode();
            methodVisitor.visitVarInsn(ALOAD, 0);
            methodVisitor.visitMethodInsn(INVOKESPECIAL, "java/lang/Object", "<init>", "()V", false);
            methodVisitor.visitInsn(RETURN);
            methodVisitor.visitMaxs(1, 1);
            methodVisitor.visitEnd();
        }

        List<RuleFactorField> fields = ruleFactor.getFields();
        for (RuleFactorField field : fields) {
            // 字段信息
            String fieldName = field.getName();
            FieldVisitor fieldVisitor = classWriter.visitField(ACC_PRIVATE, fieldName, "Ljava/lang/String;", null, null);
            fieldVisitor.visitEnd();
            // 字段的get方法
            MethodVisitor getMethodVisitor = classWriter.visitMethod(ACC_PUBLIC, "get" + upperCaseFirst(fieldName), "()Ljava/lang/String;", null, null);
            getMethodVisitor.visitCode();
            getMethodVisitor.visitVarInsn(ALOAD, 0);
            getMethodVisitor.visitFieldInsn(GETFIELD, classPath, fieldName, "Ljava/lang/String;");
            getMethodVisitor.visitInsn(ARETURN);
            getMethodVisitor.visitMaxs(1, 1);
            getMethodVisitor.visitEnd();
            // 字段的set方法
            MethodVisitor setMethodVisitor = classWriter.visitMethod(ACC_PUBLIC, "set" +upperCaseFirst(fieldName), "(Ljava/lang/String;)V", null, null);
            setMethodVisitor.visitCode();
            setMethodVisitor.visitVarInsn(ALOAD, 0);
            setMethodVisitor.visitVarInsn(ALOAD, 1);
            setMethodVisitor.visitFieldInsn(PUTFIELD, classPath, fieldName, "Ljava/lang/String;");
            setMethodVisitor.visitInsn(RETURN);
            setMethodVisitor.visitMaxs(2, 2);
            setMethodVisitor.visitEnd();
        }
        classWriter.visitEnd();
        // 生成class的字节数组
        bytes = classWriter.toByteArray();
        return this;
    }

    /**
     * 首字母大写
     *
     * @param str string
     * @return 首字母大写
     */
    public String upperCaseFirst(String str){
        String first = str.substring(0, 1);
        String firstUpperCase = first.toUpperCase(Locale.ROOT);
        String substring = str.substring(1);
        return firstUpperCase + substring;
    }

    /**
     * 将class字节数组写入文件
     *
     * @param filePath 文件路径
     * @return ClassCreator
     * @throws IOException IOException
     */
    public ClassCreator createFile(String filePath) throws IOException {
        FileUtils.writeBytes(filePath, bytes);
        return this;
    }
}
