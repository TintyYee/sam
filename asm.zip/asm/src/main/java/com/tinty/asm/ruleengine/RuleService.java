package com.tinty.asm.ruleengine;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import com.tinty.asm.ruleengine.component.ClassCreator;
import com.tinty.asm.ruleengine.model.RuleFactor;
import com.tinty.asm.ruleengine.model.RuleFactorField;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RuleService {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        // 生成规则因子
        RuleFactor ruleFactor = getRuleFactor();
        // 获取类路径
        String resourcePath = ruleFactor.getClass().getClassLoader().getResource("").getPath();// /Users/xietingting/Documents/IdeaProject/asm/asm/target/classes/
        String filePath = resourcePath + "com/tinty/asm/ruleengine/model/" + ruleFactor.getName() + ".class";
        // 生成字节码
        new ClassCreator().createByte(ruleFactor).createFile(filePath);
        // 实事转化为StRS
        Map<Object, Object> obj = new HashMap<>();
        obj.put("id", "id1");
        obj.put("name", "name1");
        obj.put("sr", "sr1");
        Object o = JSONObject.parseObject(JSON.toJSONString(obj), Class.forName("com.tinty.asm.ruleengine.model." + ruleFactor.getName()));
        System.out.println(o);
    }

    private static RuleFactor getRuleFactor(){
        RuleFactor ruleFactor = new RuleFactor();
        ruleFactor.setName("StRS");
        List<RuleFactorField> fields = new ArrayList<>();
        RuleFactorField ruleFactorField = new RuleFactorField();
        ruleFactorField.setName("id");
        RuleFactorField ruleFactorField2 = new RuleFactorField();
        ruleFactorField2.setName("name");
        RuleFactorField ruleFactorField3 = new RuleFactorField();
        ruleFactorField3.setName("sr");
        fields.add(ruleFactorField);
        fields.add(ruleFactorField2);
        fields.add(ruleFactorField3);
        ruleFactor.setFields(fields);
        return ruleFactor;
    }
}
