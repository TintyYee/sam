//public class MyClassAdapter extends ClassAdapter {
//
//    public MyClassAdapter(ClassVisitor classVisitor) {
//        super(classVisitor);
//    }
//
//    @Override
//    public MethodVisitor visitMethod(final int access, final String name,
//                                     final String desc, final String signature, final String[] exceptions) {
//        MethodVisitor mv = cv.visitMethod(access, name, desc, signature, exceptions);
//        // 仅对于 "run" 方法 施加操作
//        if (name.equals("run") && mv != null) {
//            // 使用自定义 MyMethodAdapter，实际改写方法内容
//            mv = new MyMethodAdapter(mv);
//        }
//        return mv;
//    }
//
//}
