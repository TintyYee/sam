package com.tinty.asm.demo;

import java.io.FileOutputStream;
import java.io.IOException;

public class FileUtils {
    public static String getFilePath(String path){
        return path;
    }

    public static void writeBytes(String filepath, byte[] bytes) throws IOException {
        FileOutputStream out = new FileOutputStream(filepath);
        out.write(bytes);
    }
}
