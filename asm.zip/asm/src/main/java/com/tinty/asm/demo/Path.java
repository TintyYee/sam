package com.tinty.asm.demo;

import java.io.File;
import java.io.IOException;

public class Path {
    public static void main(String[] args) throws IOException {
        String path = Path.class.getClassLoader().getResource("").getPath();
        System.out.println("getClassLoader:" + path);
        File file = new File(path);
        System.out.println("new File(path):" + file);
        File file1 = new File("");
        System.out.println("new file(\"\"):"+ file1.getCanonicalPath());
        String property = System.getProperty("user.dir");
        System.out.println("System.getProperty(\"user.dir\"):" + property);
        String property1 = System.getProperty("java.class.path");
        System.out.println("System.getProperty(\"java.class.path\"):" + property1);
    }
}
