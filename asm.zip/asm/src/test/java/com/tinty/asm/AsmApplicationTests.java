package com.tinty.asm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsmApplicationTests {

    @Test
    void contextLoads() {
    }

}
